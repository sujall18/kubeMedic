package controllers

import (
	"context"
	"fmt"
	"time"

	corev1 "k8s.io/api/core/v1"
	"k8s.io/client-go/kubernetes"
)

func AnalyzePod(
	ctx context.Context,
	clientset kubernetes.Interface,
	pod *corev1.Pod,
	tracker *IncidentTracker,
) {
	for _, containerStatus := range pod.Status.ContainerStatuses {
		key := incidentKey(pod)

		if containerStatus.State.Waiting == nil {
			tracker.Resolve(key)
			continue
		}

		reason := containerStatus.State.Waiting.Reason

		if reason != "CrashLoopBackOff" &&
			reason != "ImagePullBackOff" &&
			reason != "ErrImagePull" {
			tracker.Resolve(key)
			continue
		}

		fmt.Println()
		fmt.Println("🚨 INCIDENT DETECTED")
		fmt.Println("----------------------------------------")
		fmt.Printf("Pod: %s/%s\n", pod.Namespace, pod.Name)
		fmt.Printf("Container: %s\n", containerStatus.Name)
		fmt.Printf("Status: %s\n", reason)
		fmt.Printf("Restarts: %d\n", containerStatus.RestartCount)

		logs, err := clientset.CoreV1().
			Pods(pod.Namespace).
			GetLogs(
				pod.Name,
				&corev1.PodLogOptions{
					Container: containerStatus.Name,
					Previous:  true,
				},
			).
			Do(ctx).
			Raw()

		logText := ""
		if err != nil {
			fmt.Printf("Could not retrieve logs: %v\n", err)
		} else {
			logText = string(logs)
			fmt.Printf("Previous logs:\n%s\n", logText)
		}

		diagnosis := DiagnoseContainer(containerStatus, logText)

		// A generic CrashLoop is not enough to justify an automatic rollback.
		// First establish whether this pod belongs to a Deployment whose current
		// revision differs from an older revision.
		if reason == "CrashLoopBackOff" {
			if regression, err := DiagnoseDeploymentRegression(ctx, clientset, pod); err == nil && regression != nil {
				diagnosis = *regression
			}
		}

		fmt.Println()
		fmt.Println("Diagnosis:")
		fmt.Printf("  Problem: %s\n", diagnosis.Problem)
		fmt.Printf("  Reason: %s\n", diagnosis.Reason)
		fmt.Printf("  Severity: %s\n", diagnosis.Severity)
		fmt.Printf("  Recommended action: %s\n", diagnosis.Action)
		fmt.Println("----------------------------------------")

		if !ShouldRemediate(diagnosis) {
			fmt.Println("⏸️  No automatic remediation selected by policy")
			continue
		}

		fmt.Println()
		fmt.Println("🤖 KubeMedic will attempt automatic remediation")
		fmt.Println()

		if diagnosis.Reason == DiagnosisOOMKilled {
			fmt.Println("⚕️  REMEDIATION: Increase memory limit")

			deploymentName, oldLimit, newLimit, err := IncreaseMemoryLimit(
				ctx,
				clientset,
				pod,
			)

			if err != nil {
				fmt.Printf("❌ Remediation failed: %v\n", err)
				continue
			}

			fmt.Printf("Memory: %s → %s\n", oldLimit, newLimit)
			fmt.Println("⏳ Waiting for deployment recovery...")

			verifyCtx, cancel := context.WithTimeout(ctx, 90*time.Second)

			err = WaitForDeploymentHealthy(
				verifyCtx,
				clientset,
				pod.Namespace,
				deploymentName,
			)

			cancel()

			if err != nil {
				fmt.Printf("❌ INCIDENT UNRESOLVED: %v\n", err)
				continue
			}

			fmt.Println("✅ INCIDENT RESOLVED")
			tracker.MarkHandled(key)

			continue
		}

		result, err := RemediateCrashLoop(
			ctx,
			clientset,
			pod,
			RemediationPolicy{AutomaticRollback: true},
		)
		if err != nil {
			fmt.Printf("❌ Remediation failed: %v\n", err)
			continue
		}

		fmt.Printf("Rollback: revision %d → %d\n", result.FromRevision, result.ToRevision)
		fmt.Printf("Image: %s → %s\n", result.CurrentImage, result.PreviousImage)
		fmt.Println("⏳ Waiting for deployment recovery...")

		verifyCtx, cancel := context.WithTimeout(ctx, 90*time.Second)
		err = WaitForDeploymentHealthy(verifyCtx, clientset, pod.Namespace, result.Deployment)
		cancel()

		if err != nil {
			fmt.Printf("❌ INCIDENT UNRESOLVED: %v\n", err)
			continue
		}

		fmt.Printf("Deployment healthy: %d/%d pods Ready\n", result.DesiredReplicas, result.DesiredReplicas)
		fmt.Println("✅ INCIDENT RESOLVED")
		tracker.MarkHandled(key)
	}
}

func incidentKey(pod *corev1.Pod) string {
	return fmt.Sprintf("%s/%s", pod.Namespace, deploymentNameFromPod(pod))
}

func deploymentNameFromPod(pod *corev1.Pod) string {
	for _, ref := range pod.OwnerReferences {
		if ref.Kind == "ReplicaSet" && ref.Controller != nil && *ref.Controller {
			return ref.Name
		}
	}
	return pod.Name
}
