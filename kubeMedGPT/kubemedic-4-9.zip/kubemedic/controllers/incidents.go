package controllers

import "sync"

type IncidentState struct {
	Handling bool
	Attempts int
	Handled  bool
}

type IncidentTracker struct {
	mu        sync.Mutex
	incidents map[string]*IncidentState
}

func NewIncidentTracker() *IncidentTracker {
	return &IncidentTracker{
		incidents: make(map[string]*IncidentState),
	}
}

// Start returns true only when this incident is not already being handled.
func (t *IncidentTracker) Start(key string) bool {
	t.mu.Lock()
	defer t.mu.Unlock()

	state, exists := t.incidents[key]

	if exists {
		// Already resolved/exhausted/being handled.
		if state.Handling || state.Handled {
			return false
		}
	}

	if !exists {
		state = &IncidentState{}
		t.incidents[key] = state
	}

	state.Handling = true
	state.Attempts++

	return true
}

// Attempts returns how many remediation attempts have been made.
func (t *IncidentTracker) Attempts(key string) int {
	t.mu.Lock()
	defer t.mu.Unlock()

	if state, exists := t.incidents[key]; exists {
		return state.Attempts
	}

	return 0
}

// Resolve permanently closes the incident.
func (t *IncidentTracker) Resolve(key string) {
	t.mu.Lock()
	defer t.mu.Unlock()

	if state, exists := t.incidents[key]; exists {
		state.Handling = false
		state.Handled = true
	}
}

// Fail allows a future controlled retry.
func (t *IncidentTracker) Fail(key string) {
	t.mu.Lock()
	defer t.mu.Unlock()

	if state, exists := t.incidents[key]; exists {
		state.Handling = false
	}
}

// Forget removes an incident completely.
func (t *IncidentTracker) Forget(key string) {
	t.mu.Lock()
	defer t.mu.Unlock()

	delete(t.incidents, key)
}
