package controllers

import "sync"

type IncidentTracker struct {
	mu        sync.Mutex
	incidents map[string]bool
	handled   map[string]bool
}

func NewIncidentTracker() *IncidentTracker {
	return &IncidentTracker{
		incidents: make(map[string]bool),
		handled:   make(map[string]bool),
	}
}

func (t *IncidentTracker) IsNew(key string) bool {
	t.mu.Lock()
	defer t.mu.Unlock()

	if t.incidents[key] || t.handled[key] {
		return false
	}

	t.incidents[key] = true
	return true
}

func (t *IncidentTracker) Resolve(key string) {
	t.mu.Lock()
	defer t.mu.Unlock()

	delete(t.incidents, key)
}

func (t *IncidentTracker) MarkHandled(key string) {
	t.mu.Lock()
	defer t.mu.Unlock()

	delete(t.incidents, key)
	t.handled[key] = true
}
